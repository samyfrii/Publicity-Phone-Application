<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <title>Detail Person Page</title>
  <link rel="shortcut icon" href="http://designshack.net/favicon.ico">
  <link rel="icon" href="http://designshack.net/favicon.ico">
  <link rel="stylesheet" type="text/css" media="all" href="css/style_menu_bar.css">
  <link rel="shortcut icon" href="http://static.tmimgcdn.com/img/favicon.ico">
  <link rel="icon" href="http://static.tmimgcdn.com/img/favicon.ico">
  <link rel="stylesheet" type="text/css" media="all" href="css/switchery.min.css">
  <script type="text/javascript" src="js/switchery.min.js"></script>
    
    <style type="text/css">
    <!--
    @import url("css/style.css");
    -->
    </style>
  

<body>
 

    <h1>Detail Person Page</h1>
    
    <a class="btn" href="index.php">Home</a>
    <a class="btn" href="#">Detail Permission</a>
    <a class="btn" href="addPage.php">Grant Permission</a>
    <a class="btn" href="resume.php">Resume</a>

<table class="box-table-a" >
    <thead>
    	<tr>
            <th scope="col">Date</th>
            <th scope="col">Time of Login</th>
            <th scope="col">Time of Logout</th>
            <th scope="col" class="td_lim_size">On 
            Permission</th>
        </tr>
    </thead>
    <tbody>
    <?php
        include "php/connect.php";
        session_start();
        
        if(!isset($_GET['id']) || $_GET['id'] == "")
        {
            $_GET['id'] = 1;
        }
        
        if($_GET['id'])
                    {
                        $id = $_GET['id'];
                    }
        if(isset($_GET['start_date']))//note that this Get is from the form of the index.php page
                    {
                        $start_date = $_GET['start_date'];
                    }
        if(isset($_GET['end_date']))
                    {
                        $end_date = $_GET['end_date'];
                    }
        if(isset($_SESSION["Start_date"]))
                    {
                        $start_date = $_SESSION["Start_date"];
                        echo "session";
                    }
        if(isset($_SESSION["End_date"]))
                    {
                        $end_date = $_SESSION["End_date"];
                    }
        
        $_SESSION['previous'] = 
        basename($_SERVER['PHP_SELF']);
        //
        //
        //
        echo "<br><br><br>";
        
        $start_search_time = "";
        
        
        $filled_field = false;
        if(isset($_SESSION["Start_date"]) && 
        isset($_SESSION["End_date"]))
        {
            if(isset($_POST['end_date2']) && 
            isset($_POST['start_date2']))
            {
                
                if($_POST['end_date2'] == "" && 
                   $_POST['start_date2'] == ""     )  
                {
                    echo
                          '<div id="login-page">
                          <div class="form">
                          <form id="login-form" action="" 
                          method="post">
                          <input type="text" 
                          placeholder="YYYY/MM/DD" 
                          name="start_date2"/>
                          <input type="text" 
                          placeholder="YYYY/MM/DD"
                          name="end_date2"/>
                          <button name="press">OK</button>
                            </form>
                          </div>
                          </div>
                          <br>';   
                    
                    $filled_field = false;
                }
                else
                {
                    echo'
                  <div id="login-page">
                  <div class="form">
                  <form id="login-form" action="" 
                  method="post">
                  <input type="text" 
                  placeholder="'.$_POST["start_date2"].'3" 
                  name="start_date2"/>
                  <input type="text" 
                  placeholder="'.$_POST["end_date2"].'3"
                  name="end_date2"/>
                  <button name="press">OK</button>
                  </form>
                  </div>
                  </div>
                  <br>';
                
                $filled_field = true;
                $post_sess = false;
                $start_search_time = $_POST["start_date2"];
                $end_search_time = $_POST["end_date2"];
                }
            }
            else if($_SESSION["Start_date"] == "" || 
            $_SESSION["End_date"] == "" )
            {
                echo'
              <div id="login-page">
              <div class="form">
                <form id="login-form" action="" 
                method="post">
                  <input type="text"  
                  placeholder="YYYY/MM/DD"   
                  name="start_date2"/>
                  <input type="text" 
                  placeholder="YYYY/MM/DD" 
                  name="end_date2"/>
                  <button name="press">OK</button>

                </form>
              </div>
              </div>
              <br>';
                
             $filled_field = false;
            }
            else
            { echo'
              <div id="login-page">
              <div class="form">
                <form id="login-form" action="" 
                method="post">
                  <input type="text"  
                placeholder="'.$_SESSION["Start_date"].'2" 
                  name="start_date2"/>
                  <input type="text" 
                placeholder="'.$_SESSION["End_date"].'2"
                  name="end_date2"/>
                  <button name="press">OK</button>

                </form>
              </div>
              </div>
              <br>';
             $filled_field = true;
             $post_sess = true;
             $start_search_time = $_SESSION["Start_date"];
             $end_search_time = $_SESSION["End_date"];
            }
        
        }
        else if(isset($_POST['end_date2']) && 
            isset($_POST['start_date2']))
            {
            if($_POST['end_date2'] == "" && 
               $_POST['start_date2'] == ""     )        
        {
         echo'
          <div id="login-page">
          <div class="form">
            <form id="login-form" action="" 
            method="post">
              <input type="text" 
              placeholder="YYYY/MM/DD" 
              name="start_date2"/>
              <input type="text" 
              placeholder="YYYY/MM/DD" 
              name="end_date2"/>
              <button name="press">OK</button>

            </form>
          </div>
          </div>
          <br>';
            $filled_field = false;
           }
            else{
         echo'
          <div id="login-page">
          <div class="form">
            <form id="login-form" action="" 
            method="post">
              <input type="text" 
              placeholder="'.$_POST['start_date2'].'1" 
              name="start_date2"/>
              <input type="text" 
              placeholder="'.$_POST['end_date2'].'1" 
              name="end_date2"/>
              <button name="press">OK</button>

            </form>
          </div>
          </div>
          <br>';
            $filled_field = true;
            $post_sess = false;
            $start_search_time = $_POST['start_date2'];
            $end_search_time = $_POST['end_date2'];
           }
            }
        else{
         echo'
          <div id="login-page">
          <div class="form">
            <form id="login-form" action="" 
            method="post">
              <input type="text" 
              placeholder="YYYY/MM/DD" 
              name="start_date2"/>
              <input type="text" 
              placeholder="YYYY/MM/DD" 
              name="end_date2"/>
              <button name="press">OK</button>

            </form>
          </div>
          </div>
          <br>';
            $filled_field = false;
           }
        //
        //
        //
        
        if(isset($_GET['start_date']))
        {
            $_SESSION["Start_date"] = $_GET['start_date'];
            $_SESSION["End_date"] = $_GET['end_date'];
            $start_date = $_GET['start_date'];
            $end_date = $_GET['end_date'];
        }
        if(isset($_POST['start_date2']))
        {
            $_SESSION["Start_date"] = $_POST['start_date2'];
            $_SESSION["End_date"] = $_POST['end_date2'];
            $start_date = $_POST['start_date2'];
            $end_date = $_POST['end_date2'];
        }
        if(isset($post_sess))
        {
            $start_date = $_SESSION["Start_date"];
            $end_date = $_SESSION["End_date"];
        }
        
        
        
        $query_number_entries = "SELECT 
        CONCAT(surname,' ', firstname), 
        position from tbl_person where barcodeid 
        =".$id;

        $result = 
        mysql_query($query_number_entries,$con) or 
        die(mysql_error());

        if($rowed=mysql_fetch_array($result))
        {
            echo "<a>".$rowed[0]."</a><br>
            <a>".$rowed[1]."</a><br><br><br>";
        }
        
        
        $time_coming_hour = "";
        $time_leaving_hour = "";
        
        /*
        echo "<br>".$_SESSION['End_date']);
        echo "<br>".$_SESSION['Start_date']);
        */
        
               
        
        $add_query1 = "";
        $add_query2 = "";
        
        // note that these two ifs do
        // exactly thesame thing and if 
        // it enters the 1st if
        // it wouldn't enter the next if.
        // logical difference. 
        if((isset($_GET['start_date']) && 
           isset($_GET['end_date']))||
           (isset($_SESSION["Start_date"]) && 
           isset($_SESSION["End_date"])))
        {
            
        $add_query1 = " and (indatetime >= 
        '{$start_date} 00-00-00') 
        AND (outdatetime <= '{$end_date} 23-59-59')";
            
        /*
        $add_query2 = " and (permission_start >= 
        '{$start_date} 00-00-00') 
        AND (permission_end <= '{$end_date} 23-59-59')";*/
            
        }
        
        if(isset($_POST['start_date2']) && 
           isset($_POST['end_date2']))
        {
            if($_POST['end_date2'] != "" && 
            $_POST['start_date2'] != "" )
           {
                $add_query1 = " and (indatetime >= 
                '{$_POST['start_date2']} 00-00-00') 
                AND (outdatetime <= '{$_POST['end_date2']} 
                23-59-59')";

                
                $add_query2 = " and (permission_start >= 
                '{$_POST['start_date2']} 00-00-00') 
                AND (permission_end <= '{$_POST['end_date2']} 
                23-59-59')";
                
                echo "check if add_query";
           }
            
           else
           {
               $add_query1 = "";
               $add_query2 = "";
               // echo"else";
           }
            
        }
        
        
        
        
        $query_number_entries = "SELECT DISTINCT 
        DATE_FORMAT(indatetime, '%Y/%m/%d') AS DATE,
        CONCAT(DATE_FORMAT(indatetime, '%H'), ':', 
        DATE_FORMAT(indatetime, '%i')) AS LOGIN,
        CONCAT(DATE_FORMAT(outdatetime, '%H'), ':', 
        DATE_FORMAT(outdatetime, '%i'))  AS Logout, 
        indatetime, sio_id
        FROM tbl_signinout WHERE barcodeid =". 
        $id.$add_query1;
   
   

        $result = mysql_query($query_number_entries) or 
        die(mysql_error());
        $rowspan = 0;
        $date_common = "";
        $temp0 = "";
        $temp1 = "";
        $temp2 = "";
        $temp3 = "";
        
        $test = 0;
        $date = "";
        $permission_table_start = "";
        $permission_table_end = "";
        $actual_time = "";
        $former_time = "";
        $former_id = "";
        
        $count = 0;
        
        $number_rows = mysql_num_rows ($result);
        
        $permission = "";
        
        
        
            // Inserting the start date of the 
            // permission 
            // I might need to take create a variable for further 
            // comparison usage to store the start_date permission
            if(isset($_GET['start_date']) || 
            isset($_POST['start_date2'])  )
            {

                if($count==0)
                {
                   if($filled_field == false)
                   {

                   }else if((isset($_GET['start_date']) && 
                     $_GET['start_date'] != "")
                    || (isset($_POST['start_date2']) &&
                           $_POST['start_date2'] != ""))
                    {
                        echo'<tr>
                            <td>Start Search date</td>
                              <td  class="begin_end"
                              colspan=2>'.
                            $start_date.'
                              </td>
                              <td>-</td>
                              </tr>
                              ';
                    }
                   
                }
            }

        //
        //
        //
        //
        
        
        while($row = mysql_fetch_array($result))
        {
            $former_id = $row[4];

            
            $count++;
            
            
            
            
            
            // taking the indate time from tbl_signout 
            // 
            $actual_time = $row[3];
            
            
            
            
            // Getting the various permissions
            // from the permission table
            $query_permission_start = "SELECT *, 
            CONCAT(DATE_FORMAT(permission_start, '%H'), 
            ':', DATE_FORMAT(permission_start, '%i')) 
            AS LEFTAT, 
            CONCAT(DATE_FORMAT(permission_end,'%H'), 
            ':', DATE_FORMAT(permission_end, '%i')) AS 
            ENDAT, DATE_FORMAT(permission_start, 
            '%Y/%m/%d') AS DATE
            FROM tbl_permission WHERE permission_start 
            BETWEEN '".$former_time."' and 
            '".$actual_time."' and barcodeid = 
            ".$id;

            
            $res_start = mysql_query($query_permission_start) or 
            die(mysql_error());          
            
            if($row[2]==NULL)
            {    $temp2 = 'Person Did not Log 
            Out';}
            else
            {   $temp2 = $row[2]; 
            }
       

            $i = 0;
            while($rows_start = mysql_fetch_array($res_start))
            {
                
            if( $rows_start[3]==NULL )
                {    
                    $temp1 = $row[1];
                    $temp3 = " - ";

                }
                if($rows_start[3] != NULL)
                {  
                        $temp3 = '<a href="detailPermission.php?
                        name='.$rowed[0].'&position='.$rowed[1].
                        '&permission_id='.$rows_start[0].
                        '&permission_length='.
                        $rows_start[1].'&permission_type='.$rows_start[2].
                        '&permission_detail='.$rows_start[3].
                        '&permission_start='.$rows_start[4].
                        '&permission_end='.$rows_start[5].
                        '">'.$rows_start[1].'<a>';

                        $test = -1;

                        $temp0 = $rows_start[9];
                }
                
            
                if($rows_start[1] == "hourly")
                {
                    echo  '<tr>
                          <td>'.$rows_start[9].' </td>
                          <td>Starts at '.$rows_start[7].' </td>
                          <td>Ends at '.$rows_start[8].' </td>
                          <td>'.$temp3.' permission</td>
                          </tr>
                          ';
                }
                if($rows_start[1] == "daily")
                {   
                     echo '<tr>
                          <td>'.$rows_start[9].' </td>
                          <td colspan="2">Starts at '.$rows_start[7].' </td>
                          <td>'.$temp3.' permission starts</td>
                          </tr>
                          ';    

                }
                if($rows_start[1] == "extended")
                {

                 echo '<tr>
                      <td>'.$rows_start[9].' </td>
                      <td colspan="2">Starts at '.$rows_start[7].' </td>
                      <td>'.$temp3.' permission starts</td>
                      </tr>
                      '; 

                }/*
                if($rows_end[1] == "daily")
                {   
                     echo '<tr>
                      <td>'.$rows_end[9].' </td>
                      <td colspan="2">Ends at '.$rows_end[8].' </td>
                      <td>'.$temp3.' permission ends</td>
                      </tr>
                      ';    

                }
                if($rows_end[1] == "extended")
                {

                 echo '<tr>
                      <td>'.$rows_end[9].' </td>
                      <td colspan="2">Ends at '.$rows_end[8].' </td>
                      <td>'.$temp3.' permission ends</td>
                      </tr>
                      ';  

                }
                */
                
            }

            /*
            if ( strtotime($row[0]) != 
                strtotime($rows_start[9]) )
            {
                echo "date equal".$rows_start[9];
            }*/


            if($row[2]==NULL)
            {$temp0 = 'Person Did not Log Out';}
            else
            {   $temp0 = $row[2];  }


                $former_time = $row[3];
                $date_common = $row[0];
            
            // if to check if there is a permission 
            // and attach it to a date
            // 
            

            
               echo '<tr>
                          <td>'.$row[0].' </td>
                          <td>'.$row[1].' </td>
                          <td>'.$temp0.' </td>
                          <td> - </td>
                          </tr>
                          '; 
            
                 

             

        }//end of while
        
        
    
        // Doing the code to the end 
        // date permissions in cases 
        // they appear at the end 
        // Status: #notcomplete
        //
        // **** My logic ****
        // comparing the last day with the 
        // "end_search_date" and search in the 
        // table permission for permissions
        // in that interval
      if((isset($_GET['end_date']) || 
      isset($_POST['end_date2'])) && $start_search_time != "")
      {
        
        
        $permission_table_start ="SELECT *, 
        CONCAT(DATE_FORMAT(permission_start, '%H'), 
        ':', DATE_FORMAT(permission_start, '%i')) 
        AS LEFTAT, 
        CONCAT(DATE_FORMAT(permission_end,'%H'), 
        ':', DATE_FORMAT(permission_end, '%i')) AS 
        ENDAT, DATE_FORMAT(permission_start, 
        '%Y/%m/%d') AS DATE
        FROM tbl_permission WHERE permission_start 
        BETWEEN '".$actual_time."' and 
        '".$end_search_time." 23-59-59' and 
        barcodeid = 
        ".$id;
            
            
        $res = mysql_query($permission_table_start) or 
        die(mysql_error());
          
          
        // Check if results are returned  
        
            while($rows_start = mysql_fetch_array($res))
            {
                $temp1 = '<td><a href="">'.$rows_start[3].
                '<a></td>';

                $temp1 = $rows_start[7];

                $temp2 = $rows_start[8];

                $temp3 = '<a href="detailPermission.php?
                name='.$rowed[0].'&position='.$rowed[1].
                '&permission_id='.$rows_start[0].
                '&permission_length='.$rows_start[1].
                '&permission_type='.$rows_start[2].
                '&permission_detail='.$rows_start[3].
                '&permission_start='.$rows_start[4].
                '&permission_end='.$rows_start[5].
                '">'.$rows_start[1].'<a>';
                echo  'rows_end'.$rows_start[9];

                echo "Actual_time ". $actual_time.'<br>';

                if($rows_start[1] == "hourly")
                {
                    echo  '<tr>
                          <td>'.$rows_start[9].' </td>
                          <td>Starts at '.$temp1.' </td>
                          <td>Ends at '.$temp2.' </td>
                          <td>'.$temp3.' permission</td>
                          </tr>
                          ';
                }else
                {
                    echo  '<tr>
                          <td>'.$rows_start[9].'</td>
                          <td colspan="2">Starts at '.$temp1.' 
                          </td>
                          <td>'.$temp3.' 
                          permission </td>
                          </tr>
                          ';
                }
   
        
           }
          
          echo'<tr>
                <td>End Search date</td>
                  <td  class="begin_end"
                  colspan=2>'.
                $end_date.'
                  </td>
                  <td>-</td>
                  </tr>
                  ';

        
        }
        
            


    
    ?>
       
    </tbody>
    </table>

    
</body>
    </html>