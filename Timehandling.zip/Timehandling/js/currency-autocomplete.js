
$(function(){
  var currencies = [
    { value: 'George', data: 'Nkeze' },
    { value: 'Lynn', data: 'Nanyongo' },
    { value: 'Germaine', data: 'Afa' },
    { value: 'Wilfred', data: 'Ndongko' },
    { value: 'George', data: 'Atem' },
    { value: 'Mary', data: 'Kombe' },
    { value: 'Hako', data: 'Touko' },
    { value: 'Eyong', data: 'Eyong' },
    { value: 'Benedicta', data: 'Atangana' },
    { value: 'Akumenzoh', data: 'Etumbeh' },
    { value: 'Obasi', data: 'Marinus' },
    { value: 'Agbor', data: 'Betrand' },
    { value: 'Mary', data: 'Evenye' },
    { value: 'Felicitas', data: 'Mokom' },
    { value: 'Fofie', data: 'Douanla' },
    { value: 'Ngatchu', data: 'Damen' },
    { value: 'Tiako', data: 'Fani' },
    { value: 'Gilemond', data: 'Nchiwoo' },
  ];
  
  // setup autocomplete function pulling from currencies[] array
  $('#autocomplete').autocomplete({
    lookup: currencies,
    onSelect: function (suggestion) {
      var thehtml = '<strong>Name:</strong> ' + suggestion.data + ' <br> <strong>Surname:</strong> ' + suggestion.value  ;
      $('#outputcontent').html(thehtml);
    }
  });
  

});