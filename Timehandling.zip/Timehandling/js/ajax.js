$(document).ready(function() {
            
                $("button").click(function(){
                    
                var xmlhttp;
                if (window.XMLHttpRequest) {
                    xmlhttp = new XMLHttpRequest();
                } else {
                    xmlhttp = new 
                    ActiveXObject("Microsoft.XMLHTTP");
                }
                var test = "";
                xmlhttp.onreadystatechange = function() {
                    if (xmlhttp.readyState == 4 && 
                        xmlhttp.status == 200) {
                
                test = xmlhttp.responseText;
                        
                document.getElementById("test").innerHTML 
                    = test;
                    }
                };
                xmlhttp.open("GET", 
                             "ajax_perm_person.php", 
                             true);
                xmlhttp.send();
                
        });
    });