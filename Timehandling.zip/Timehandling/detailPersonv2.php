<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Time handling platform... </title>
<style type="text/css">
<!--
@import url("css/style.css");
-->
</style>
  
</head>
<body>
 
<?php

    //require_once('php/fetcharray.php');
    session_start();
    if(isset($_SESSION['Start_date']) && isset($_SESSION['Start_date']))
    {
    
        echo'
      <div id="login-page">
      <div class="form">
        <form id="login-form" action="" method="post">
          <input type="text" placeholder='.$_SESSION['Start_date'].'  name="start_date_dp"/>
          <input type="text" placeholder='.$_SESSION['End_date'].' name="end_date_dp"/>
          <button name="press">OK</button>

        </form>
      </div>
    </div>';
        
    }else{
        
         echo'
      <div id="login-page">
      <div class="form">
        <form id="login-form" action="" method="post">
          <input type="text" placeholder="YYYY/MM/DD"  name="start_date_dp"/>
          <input type="text" placeholder="YYYY/MM/DD" name="end_date_dp"/>
          <button name="press">OK</button>

        </form>
      </div>
    </div>';
    }

/* echo'<div id="login-page">
      <div class="form">
        <form id="login-form" action="" method="post">
          <input type="text" placeholder="YYYY/MM/DD"  name="start_date"/>
          <input type="text" placeholder="YYYY/MM/DD" name="end_date"/>
          <button name="press">OK</button>

        </form>
      </div>
    </div>
    ';
*/
    
    ?>
    
    <br>

<table class="box-table-a" >
    <thead>
    	<tr>
            <th scope="col">Date</th>
            <th scope="col">Time of Login</th>
            <th scope="col">Time of Logout</th>
            <th scope="col" class="td_lim_size">On Permission</th>
        </tr>
    </thead>
    <tbody>
    <?php
        $id = "";
        $start_date = "";
        $end_date = "";
        
        echo "detailPerson<br>";
        include "php/connect.php";  
        if(isset($_GET['id']))
                    {
                        $id = $_GET['id'];
                    }
        if(isset($_GET['start_date']))
                    {
                        $start_date = $_GET['start_date'];
                    }
        if(isset($_GET['end_date']))
                    {
                        $end_date = $_GET['end_date'];
                    }
        $query_number_entries = "SELECT CONCAT(surname, ' ', firstname), 
        position from tbl_person where barcodeid =".$id;

        $result = mysql_query($query_number_entries,$con) or die(mysql_error());

        if($rowed=mysql_fetch_array($result))
        {
            echo "<a>".$rowed[0]."</a><br>";
            echo "<a>".$rowed[1]."</a><br>";
        }
        
        
        $time_coming_hour = "";
        $time_leaving_hour = "";
        
        if(isset($_POST['start_date_dp']) and isset($_POST['end_date_dp'])){
            
            echo '<a>start_date_dp '.$_POST['start_date_dp'].'</a><br>';
             
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            //
            
            
            
             $query_number_entries = "SELECT DISTINCT
        DATE_FORMAT(indatetime, '%Y-%m-%d') AS DATE,
        CONCAT(DATE_FORMAT(indatetime, '%H'), ':', DATE_FORMAT(indatetime, '%i')) AS LOGIN,
        CONCAT(DATE_FORMAT(outdatetime, '%H'), ':', DATE_FORMAT(outdatetime, '%i'))  AS Logout, indatetime
        FROM tbl_signinout WHERE barcodeid =". 
        $id." and indatetime >= '{$_POST['start_date_dp']} 00-00-00' AND outdatetime <= '{$_POST['end_date_dp']} 23-59-59'";
        
        
   

        $result = mysql_query($query_number_entries) or die(mysql_error());
        $rowspan = 0;
        $date_common = "";
        
        $temp0 = "";
        $temp1 = "";
        $temp2 = "";
        $temp3 = "";
        
        $test = 0;
        $date = "";
        $permission_table = "";
        $actual_time = "";
        $former_time = "";
        
        $permission = "";
        
        while($row = mysql_fetch_array($result))
        {


            $actual_time = $row[3];


            $permission_table ="SELECT *, CONCAT(DATE_FORMAT(permission_start, '%H'), 
            ':', DATE_FORMAT(permission_start, '%i')) AS LEFTAT, 
            CONCAT(DATE_FORMAT(permission_end, '%H'), ':', 
            DATE_FORMAT(permission_end, '%i')) AS ENDAT, DATE_FORMAT(permission_start, '%Y-%m-%d') AS DATE
            FROM tbl_permission WHERE permission_start BETWEEN '".$former_time."' and '".$actual_time."' and barcodeid = ".$id
            ." and permission_start >= '{$start_date} 00-00-00' AND permission_end <= '{$end_date} 23-59-59'";


            $res = mysql_query($permission_table) or die(mysql_error());
            $rows = mysql_fetch_array($res);
            $test = 0;
            
            
              $temp0 = $row[0];   
            
            
            if($row[2]==NULL)
                    {    $temp2 = 'Person Did not Log Out';}
                    else
                    {   $temp2 = $row[2];  }


                    if($rows[3]==NULL)
                    {    
                        $temp1 = $row[1];
                        $temp3 = " - ";

                    }
                    else
                    {  
                    $temp1 = '<td><a href="">'.$rows[3].
                    '<a></td>';


                        $temp1 = $rows[7];
                        $temp2 = $rows[8];
                        $temp3 = '<a href="detailPermission.php?name='.$rowed[0].'&position='.$rowed[1].'&permission_id='.$rows[0].'&permission_length='.$rows[1].'&permission_type='.$rows[2].'&permission_detail='.$rows[3].'&permission_start='.$rows[4].'&permission_end='.$rows[5].'">'.$rows[1].'<a>';

                        $test = -1;
                    $temp0 =  date('Y-m-d', strtotime($rows[9]));
                    $temp0 = $rows[9];


                    }

                     


                    $former_time = $row[3];
                    $date_common = $row[0];

            
            if($rows[1] == null)
            {
                echo '<tr>
                          <td>'.$temp0.' </td>
                          <td>'.$temp1.' </td>
                          <td>'.$temp2.' </td>
                          <td>'.$temp3.' </td>
                          </tr>
                          '; 
            }
            else if($rows[1] == "hourly")
            {
                
                   echo  '<tr>
                          <td>'.$temp0.' </td>
                          <td>'.$temp1.' </td>
                          <td>'.$temp2.' </td>
                          <td>'.$temp3.' permission </td>
                          </tr>
                          ';
                
            }
            else if($rows[1] == "daily")
            {
                
                     echo '<tr>
                          <td>'.$temp0.' </td>
                          <td>'.$temp1.' </td>
                          <td>-</td>
                          <td>'.$temp3.' permission starts</td>
                          </tr>
                          ';    

                        $temp0_extended =  date('Y-m-d', strtotime($rows[5]));
                     echo '<tr>
                          <td>'.$temp0_extended.' </td>
                          <td>-</td>
                          <td>'.$temp2.' </td>
                          <td>'.$temp3.' permission ends </td>
                          </tr>
                          ';
                
            }
            else if($rows[1] == "extended")
            {
                 
             echo '<tr>
                  <td>'.$temp0.' </td>
                  <td>'.$temp1.' </td>
                  <td>-</td>
                  <td>'.$temp3.' permission starts </td>
                  </tr>
                  '; 
                
            $temp0_extended =  date('Y-m-d', strtotime($rows[5]));
             echo '<tr>
                  <td>'.$temp0_extended.' </td>
                  <td>-</td>
                  <td>'.$temp2.' </td>
                  <td>'.$temp3.' permission ends </td>
                  </tr>
                  '; 
              
            }
            
            
            
        }
            
        }
        else{echo "if(!isset(start_date)<br>";
             $query_number_entries = "SELECT DISTINCT
        DATE_FORMAT(indatetime, '%Y-%m-%d') AS DATE,
        CONCAT(DATE_FORMAT(indatetime, '%H'), ':', DATE_FORMAT(indatetime, '%i')) AS LOGIN,
        CONCAT(DATE_FORMAT(outdatetime, '%H'), ':', DATE_FORMAT(outdatetime, '%i'))  AS Logout, indatetime
        FROM tbl_signinout WHERE barcodeid =". 
        $id;
        
        
   

        $result = mysql_query($query_number_entries) or die(mysql_error());
        $rowspan = 0;
        $date_common = "";
        
        $temp0 = "";
        $temp1 = "";
        $temp2 = "";
        $temp3 = "";
        
        $test = 0;
        $date = "";
        $permission_table = "";
        $actual_time = "";
        $former_time = "";
        
        $permission = "";
        
        while($row = mysql_fetch_array($result))
        {


            $actual_time = $row[3];


            $permission_table ="SELECT *, CONCAT(DATE_FORMAT(permission_start, '%H'), 
            ':', DATE_FORMAT(permission_start, '%i')) AS LEFTAT, 
            CONCAT(DATE_FORMAT(permission_end, '%H'), ':', 
            DATE_FORMAT(permission_end, '%i')) AS ENDAT, DATE_FORMAT(permission_start, '%Y-%m-%d') AS DATE
            FROM tbl_permission WHERE permission_start BETWEEN '".$former_time."' and '".$actual_time."' and barcodeid = ".$id;


            $res = mysql_query($permission_table) or die(mysql_error());
            $rows = mysql_fetch_array($res);
            $test = 0;
            
            
              $temp0 = $row[0];   
            
            
            if($row[2]==NULL)
                    {    $temp2 = 'Person Did not Log Out';}
                    else
                    {   $temp2 = $row[2];  }


                    if($rows[3]==NULL)
                    {    
                        $temp1 = $row[1];
                        $temp3 = " - ";

                    }
                    else
                    {  
                    $temp1 = '<td><a href="">'.$rows[3].
                    '<a></td>';


                        $temp1 = $rows[7];
                        $temp2 = $rows[8];
                        $temp3 = '<a href="detailPermission.php?name='.$rowed[0].'&position='.$rowed[1].'&permission_id='.$rows[0].'&permission_length='.$rows[1].'&permission_type='.$rows[2].'&permission_detail='.$rows[3].'&permission_start='.$rows[4].'&permission_end='.$rows[5].'">'.$rows[1].'<a>';

                        $test = -1;
                       
                    $temp0 = $rows[9];


                    }

                     


                    $former_time = $row[3];
                    $date_common = $row[0];

            
            if($rows[1] == null)
            {
                echo '<tr>
                          <td>'.$temp0.' </td>
                          <td>'.$temp1.' </td>
                          <td>'.$temp2.' </td>
                          <td>'.$temp3.' </td>
                          </tr>
                          '; 
            }
            else if($rows[1] == "hourly")
            {
                
                   echo  '<tr>
                          <td>'.$temp0.' </td>
                          <td>'.$temp1.' </td>
                          <td>'.$temp2.' </td>
                          <td>'.$temp3.' permission </td>
                          </tr>
                          ';
                
            }
            else if($rows[1] == "daily")
            {
                
                     echo '<tr>
                          <td>'.$temp0.' </td>
                          <td>'.$temp1.' </td>
                          <td>-</td>
                          <td>'.$temp3.' permission starts</td>
                          </tr>
                          ';    
                
                        $temp0_extended =  date('Y-m-d', strtotime($rows[5]));
                     echo '<tr>
                          <td>'.$temp0_extended.' </td>
                          <td>-</td>
                          <td>'.$temp2.' </td>
                          <td>'.$temp3.' permission ends </td>
                          </tr>
                          ';
                
            }
            else if($rows[1] == "extended")
            {
                 
             echo '<tr>
                  <td>'.$temp0.' </td>
                  <td>'.$temp1.' </td>
                  <td>-</td>
                  <td>'.$temp3.' permission starts </td>
                  </tr>
                  '; 
                
            $temp0_extended =  date('Y-m-d', strtotime($rows[5]));
             echo '<tr>
                  <td>'.$temp0_extended.' </td>
                  <td>-</td>
                  <td>'.$temp2.' </td>
                  <td>'.$temp3.' permission ends </td>
                  </tr>
                  '; 
              
            }
            }
        }
       

    ?>
       
    </tbody>
    </table>

    
    <br><br>
    
    

</body>
</html>