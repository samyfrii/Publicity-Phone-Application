<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en-US">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <title>Permission Add Page</title>
  <link rel="shortcut icon" href="http://designshack.net/favicon.ico">
  <link rel="icon" href="http://designshack.net/favicon.ico">
  <link rel="stylesheet" type="text/css" media="all" href="css/style_2.css">
  <script type="text/javascript" src="js/jquery-1.9.1.min.js"></script>
  <script type="text/javascript" src="js/jquery.autocomplete.min.js"></script>
  <script type="text/javascript" src="js/currency-autocomplete.js"></script>
  <link rel="shortcut icon" href="http://static.tmimgcdn.com/img/favicon.ico">
  <link rel="icon" href="http://static.tmimgcdn.com/img/favicon.ico">
  <link rel="stylesheet" type="text/css" media="all" href="css/styles.css">
  <link rel="stylesheet" type="text/css" media="all" href="css/switchery.min.css">
  <script type="text/javascript" src="js/switchery.min.js"></script>

  
</head>

<body>

    <h1>Grant Permission Page</h1>
    
    <a class="btn" href="index.php">Home</a>
    <a class="btn" href="detailPerson.php">Detail Permission</a>
    <a class="btn" href="addPage.php">Grant Permission</a>
    <a class="btn" href="resume.php">Resume</a>
    <br><br>
   
    
  <div id="w">
    <div id="content">
      <h1>Add A Permission Form</h1>
      <p>Just start typing and results will be supplied 
          from the database.</p>
      
      <div id="searchfield">
        <form><input type="text" name="currency" class="biginput" id="autocomplete"></form>
      </div><!-- @end #searchfield -->
      
      <div id="outputbox">
        <p id="outputcontent">Start entrying the name or surname and the results will create the form below.</p>
      </div>
    </div><!-- @end #content -->
  </div><!-- @end #w -->

   
  
   
    <link href='http://fonts.googleapis.com/css?family=Oswald:300' rel='stylesheet' type='text/css'>

    
    
     <div id="wrapper">
    
      <h2 id="show_1">Person #1 Name</h2>
  
  <form onsubmit="return false" class="form" id="form_1">
      <h2>Person Added # 1</h2>
  <div class="col-3">
    <label>
      Name
      <input placeholder="NAME" id="name" name="name" tabindex="1" required>
    </label>
  </div>
  <div class="col-3">
    <label>
      surname
      <input placeholder="SURNAME" id="surname" name="surname" tabindex="2" required>
    </label>
  </div>
  

  <div class="col-3">
    <label>
     Permission Detail
      <input placeholder="Permission Detail" id="experience" name="experience" tabindex="7">
    </label>
  </div>
  <div class="col-3">
    <label>
      Permission Type
      <select tabindex="5">
        <option>SOCIAL</option>
        <option>COORPORATE</option>
      </select>
    </label>
  </div>
      <div class="col-3">
    <label>
      Start Time
      <select tabindex="5">
        <option>08:00</option>
        <option>10:00</option>
        <option>12:00</option>
        <option>14:00</option>
        <option>16:00</option>
      </select>
    </label>
      </div>
    
  
  <div class="col-3">
    <label>
      Start Day
      <select tabindex="5">
        <option>01</option>
        <option>02</option>
        <option>03</option>
        <option>04</option>
        <option>05</option>
        <option>06</option>
        <option>07</option>
        <option>08</option>
        <option>09</option>
        <option>10</option>
        <option>11</option>
        <option>12</option>
        <option>13</option>
        <option>14</option>
        <option>15</option>
        <option>16</option>
        <option>17</option>
        <option>18</option>
        <option>19</option>
        <option>20</option>
        <option>21</option>
        <option>22</option>
        <option>23</option>
        <option>24</option>
        <option>25</option>
        <option>26</option>
        <option>27</option>
        <option>28</option>
        <option>29</option>
        <option>30</option>
        <option>31</option>
      </select>
    </label>
  </div>
  
  
  <div class="col-3">
    <label>
      Start Month
      <select tabindex="5">
        <option>January</option>
        <option>February</option>
        <option>March</option>
        <option>April</option>
        <option>May</option>
        <option>June</option>
        <option>July</option>
        <option>August</option>
        <option>September</option>
        <option>October</option>
        <option>November</option>
        <option>December</option>
      </select>
    </label>
  </div>
      
  <div class="col-3">
    <label>
      Start Year
      <select tabindex="5">
        <option>2017</option>
        <option>2018</option>
        <option>2019</option>
        <option>2020</option>
        <option>2021</option>
        <option>2022</option>
        <option>2023</option>
        <option>2024</option>
        <option>2025</option>
        <option>2026</option>
        <option>2027</option>
        <option>2028</option>
        <option>2029</option>
        <option>2030</option>
      </select>
    </label>
  </div>
  
  <div class="col-3">
    <label>
      End Time
      <select tabindex="5">
        <option>08:00</option>
        <option>10:00</option>
        <option>12:00</option>
        <option>14:00</option>
        <option>16:00</option>
      </select>
    </label>
  </div>
      
  <div class="col-3">
    <label>
      End Year
      <select tabindex="5">
        <option>2017</option>
        <option>2018</option>
        <option>2019</option>
        <option>2020</option>
        <option>2021</option>
        <option>2022</option>
        <option>2023</option>
        <option>2024</option>
        <option>2025</option>
        <option>2025</option>
        <option>2026</option>
        <option>2027</option>
        <option>2028</option>
        <option>2029</option>
        <option>2030</option>
      </select>
    </label>
  </div>
  <div class="col-3">
    <label>
      End Month
      <select tabindex="5">
        <option>January</option>
        <option>February</option>
        <option>March</option>
        <option>April</option>
        <option>May</option>
        <option>June</option>
        <option>July</option>
        <option>August</option>
        <option>September</option>
        <option>October</option>
        <option>November</option>
        <option>December</option>
      </select>
    </label>
  </div>
  <div class="col-3">
    <label>
      End Day
      <select tabindex="5">
        <option>01</option>
        <option>02</option>
        <option>03</option>
        <option>04</option>
        <option>05</option>
        <option>06</option>
        <option>07</option>
        <option>08</option>
        <option>09</option>
        <option>10</option>
        <option>11</option>
        <option>12</option>
        <option>13</option>
        <option>14</option>
        <option>15</option>
        <option>16</option>
        <option>17</option>
        <option>18</option>
        <option>19</option>
        <option>20</option>
        <option>21</option>
        <option>22</option>
        <option>23</option>
        <option>24</option>
        <option>25</option>
        <option>26</option>
        <option>27</option>
        <option>28</option>
        <option>29</option>
        <option>30</option>
        <option>31</option>
      </select>
    </label>
  </div>
      
    
  
  <div class="col-submit">
    <button class="submitbtn" id="hide_1">Submit Form</button>
  </div>
  
  </form>
  </div>
       
<script type="text/javascript">
var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));

elems.forEach(function(html) {
  var switchery = new Switchery(html);
});
</script>
</body>
</html>