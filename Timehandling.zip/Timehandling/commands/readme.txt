CREATE TABLE tbl_permission (
    permission_id int AUTO_INCREMENT,
    permission_length ENUM('daily','hourly','extended'),
    permission_type ENUM('social','coorporate'),
    permission_detail varchar(255) NOT null,
    permission_start datetime,
    permission_end datetime,
    barcodeid bigint(20),
    PRIMARY KEY (permission_id),
    FOREIGN KEY (barcodeid) REFERENCES tbl_person(barcodeid)
    );
    
INSERT INTO tbl_permission (permission_length, permission_type, permission_detail, permission_start, permission_end, barcodeid) VALUES('daily','coorporate','A visit to CRTV', '2017-03-24 13:30:00','2017-03-25 08:00:00', 1) 

SELECT * FROM (SELECT DISTINCT CONCAT(EXTRACT(DAY FROM permission_start),' / ', EXTRACT(MONTH FROM permission_start)) AS DATE_STARTED, CONCAT(EXTRACT(HOUR FROM permission_start), ':', EXTRACT(MINUTE FROM permission_start)) AS 'Log in At', CONCAT(EXTRACT(DAY FROM permission_end),' / ', EXTRACT(MONTH FROM permission_end)) AS DATE_ENDED, CONCAT(EXTRACT(HOUR FROM permission_end), ':',EXTRACT(MINUTE FROM permission_end)) AS 'Log out At', permission_detail, barcodeid FROM tbl_permission ) tbl_permission WHERE (barcodeid = 1 and DATE_STARTED = "24 / 3")


SELECT * FROM (SELECT DISTINCT CONCAT(EXTRACT(DAY FROM permission_start),'/', EXTRACT(MONTH FROM permission_start),'/', EXTRACT(YEAR FROM permission_end)) AS DATE_STARTED, CONCAT(EXTRACT(HOUR FROM permission_start), ':', EXTRACT(MINUTE FROM permission_start)) AS 'Log in At', CONCAT(EXTRACT(DAY FROM permission_end),'/', EXTRACT(MONTH FROM permission_end),'/', EXTRACT(YEAR FROM permission_end)) AS DATE_ENDED, CONCAT(EXTRACT(HOUR FROM permission_end), ':',EXTRACT(MINUTE FROM permission_end)) AS 'Log out At', permission_detail, barcodeid FROM tbl_permission ) tbl_permission WHERE (barcodeid = 1 and DATE_STARTED = "24/3/2017") 

<?php
$query_person_need_reason = "SELECT DISTINCT CONCAT(EXTRACT(DAY FROM permission_start),' / ', EXTRACT(MONTH FROM permission_start)) AS 'DATE STARTED', CONCAT(EXTRACT(HOUR FROM permission_start),':', EXTRACT(MINUTE FROM permission_start)) AS 'Log in At', CONCAT(EXTRACT(DAY FROM permission_end),' / ', EXTRACT(MONTH FROM permission_end)) AS 'DATE ENDED',CONCAT(EXTRACT(HOUR FROM permission_end),EXTRACT(MINUTE FROM permission_end)) AS 'Log out At', permission_reason FROM tbl_permission WHERE barcodeid = 1 ";

$query_person_need_reason_modified_day = "SELECT DAYNAME(indatetime) AS 'Day' , indatetime, outdatetime from tbl_signinout where (barcodeid = 1 and outdatetime is null) ";



?>