<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <title>Time handling platform</title>
  <link rel="shortcut icon" href="http://designshack.net/favicon.ico">
  <link rel="icon" href="http://designshack.net/favicon.ico">
  <link rel="stylesheet" type="text/css" media="all" href="css/style_menu_bar.css">
  <link rel="shortcut icon" href="http://static.tmimgcdn.com/img/favicon.ico">
  <link rel="icon" href="http://static.tmimgcdn.com/img/favicon.ico">
  <link rel="stylesheet" type="text/css" media="all" href="css/switchery.min.css">
  <script type="text/javascript" src="js/switchery.min.js"></script>
    
    <style type="text/css">
<!--
@import url("css/style.css");
-->
</style>
  

<body>
 

    <h1>Home Page</h1>
    
    <a class="btn" href="#">Home</a>
    <a class="btn" href="detailPerson.php">Detail Permission</a>
    <a class="btn" href="addPage.php">Grant Permission</a>
    <a class="btn" href="resume.php">Resume</a>
    <br><br><br>
 
    <?php
    // Create connection
    include "php/connect.php";
    session_start();
    
    
    //
    //
    //
    if (isset($_SESSION['previous'])) {
    if (basename($_SERVER['PHP_SELF']) != 
        $_SESSION['previous']) {
        session_unset();
        ### or alternatively, you can use this for  specific variables:
        ### unset($_SESSION['varname']);
    //    $_SESSION['check_unset'] = "true";
       }
    }
    //
    //
    //
    if(isset($_SESSION["Start_date"]) && 
    isset($_SESSION["End_date"]) && 
    isset($_POST['end_date']) && 
    isset($_POST['start_date']))
    {
        
        if( $_POST['start_date'] != "" && 
          $_POST['end_date'] != "" )
        {
             echo'
      <div id="login-page">
      <div class="form">
        <form id="login-form" action="" method="post">
          <input type="text" 
          placeholder='.$_POST['start_date'].' 
          name="start_date"/>
          <input type="text" 
          placeholder='.$_POST['end_date'].' 
          name="end_date"/>
          <button name="press">OK</button>

        </form>
      </div>
      </div>';
        }else if( $_SESSION["Start_date"] == "" && 
        $_SESSION["End_date"] == "" )
        {
             echo'
      <div id="login-page">
      <div class="form">
        <form id="login-form" action="" method="post">
          <input type="text" placeholder="YYYY/MM/DD" 
          name="start_date"/>
          <input type="text" placeholder="YYYY/MM/DD" 
          name="end_date"/>
          <button name="press">OK</button>

        </form>
      </div>
      </div>';
        }else
        {
            echo'
      <div id="login-page">
      <div class="form">
        <form id="login-form" action="" method="post">
          <input type="text" placeholder="YYYY/MM/DD" name="start_date1"/>
          <input type="text" placeholder="YYYY/MM/DD" name="end_date"/>
          <button name="press">OK</button>

        </form>
      </div>
    </div>';
        }
        
    }else if(@$_POST['start_date'] != "" && 
          @$_POST['end_date'] != ""){
        echo'
      <div id="login-page">
      <div class="form">
        <form id="login-form" action="" method="post">
          <input type="text" 
          placeholder='.$_POST['start_date'].' 
          name="start_date"/>
          <input type="text" 
          placeholder='.$_POST['end_date'].' 
          name="end_date"/>
          <button name="press">OK</button>

        </form>
      </div>
    </div>';
    }else{
        echo'
      <div id="login-page">
      <div class="form">
        <form id="login-form" action="" method="post">
          <input type="text" placeholder="YYYY/MM/DD" 
          name="start_date"/>
          <input type="text" placeholder="YYYY/MM/DD" 
          name="end_date"/>
          <button name="press">OK</button>

        </form>
      </div>
    </div>';
    }



    ?>
    
    
    <br><br><br>

<table class="box-table-a" >
    <thead>
    	<tr>
        	<th scope="col">Name</th>
            <th scope="col">Total Hours</th>
            <th scope="col">Number Of Days</th>
            <th scope="col">Average Hours Per Day</th>
            <th scope="col">Expected Avg</th>
        </tr>
    </thead>
    <tbody>
    <?php

    include "php/fetcharray.php"

    ?>

       
    </tbody>
    </table>

    <table class="box-table-a" >
    
    </table>

    
    <br><br>

</body>
</html>