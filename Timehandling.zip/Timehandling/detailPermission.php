<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8">
  <title>Time handling platform... </title>
  <link rel="shortcut icon" href="http://designshack.net/favicon.ico">
  <link rel="icon" href="http://designshack.net/favicon.ico">
  <link rel="stylesheet" type="text/css" media="all" href="css/style_menu_bar.css">
  <link rel="shortcut icon" href="http://static.tmimgcdn.com/img/favicon.ico">
  <link rel="icon" href="http://static.tmimgcdn.com/img/favicon.ico">
  <link rel="stylesheet" type="text/css" media="all" href="css/switchery.min.css">
  <script type="text/javascript" src="js/switchery.min.js"></script>
    
    <style type="text/css">
<!--
@import url("css/style.css");
-->
</style>
  

<body>
 

    <h1>The Details of the permission granted</h1>
    
    <a class="btn" href="index.php">Home</a>
    <a class="btn" href="detailPerson.php">Detail Permission</a>
    <a class="btn" href="addPage.php">Grant Permission</a>
    <a class="btn" href="php/temp.php">Resume</a>
    <br><br><br>
    
    
<?php
// Create connection
 include "php/connect.php"; 
 session_start();
    $name = "";
    $position = "";
    $permission_id = "";
    $permission_length = "";
    $permission_type = "";
    $permission_detail = "";
    $permission_start = "";
    $permission_end = "";
    
    if($_GET['name'])
                {
                    $name = $_GET['name'];
                }
    if($_GET['position'])
                {
                    $position = $_GET['position'];
                }
    if($_GET['permission_id'])
                {
                    $permission_id = $_GET['permission_id'];
                }
    if($_GET['permission_length'])
                {
                    $permission_length = $_GET['permission_length'];
                }
    if($_GET['permission_type'])
                {
                    $permission_type = $_GET['permission_type'];
                }
    if($_GET['permission_detail'])
                {
                    $permission_detail = $_GET['permission_detail'];
                }
    if($_GET['permission_start'])
                {
                    $permission_start = $_GET['permission_start'];
                }
    if($_GET['permission_end'])
                {
                    $permission_end = $_GET['permission_end'];
                }
    
    
    
    
        echo "<br><br><a>".$name." occupying the position of ".$position." had a permission of type 
        ".$permission_type." and of length 
        ".$permission_length.". The permission started on 
        the '".$permission_start."' and finished on the  '".$permission_end."<a>'.";
        echo "<br><br><br><a>Title of the permission <a><br><h2>'".$permission_detail."'</h2>";
   ?>

    
    <br><br>
    
    

</body>
</html>