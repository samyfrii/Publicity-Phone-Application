A Pen created at CodePen.io. You can find this one at http://codepen.io/akhbar/pen/oLqnu.

 Lightbox technique using no javascript whatsoever

Forked from [Mario Nebl](http://codepen.io/marionebl/)'s Pen [Pure CSS lightbox technique](http://codepen.io/marionebl/pen/fensm/).